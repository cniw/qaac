Refer articel: https://github.com/nu774/qaac/wiki/Installation

Download site:
  http://www.rarewares.org/lossless.php
  http://www.wavpack.com/downloads.html
  http://www.thbeck.de/Tak/Tak.html
  http://www.mega-nerd.com/libsndfile/

Current version:
  FLAC 1.3.2
  WavPack 5.1.0
  TAK 2.3.0
  libsndfile 1.0.28
